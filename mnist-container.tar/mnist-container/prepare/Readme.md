Python script to download Mnist dataset and save it in the following location
/mnt/data/mnist
