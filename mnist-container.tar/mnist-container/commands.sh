#!/bin/bash

command=$1
device=$2
if [ -z "$command" ] || [ -z "$device" ]
then
	echo -e "#########################\nPlease specify a command and device\n(Command) <build> build and push the docker image, <run> to run mnist training\n(Device) <CPU> or <GPU>\n#########################"
      exit 1	
fi
echo $command
##### to use the GPU image, replace mnist-training-cpu to "mnist-training-gpu" #####

if [ "$device" = "GPU" ] 
then
	docker_image_name="mnist-training-gpu"
else
	docker_image_name="mnist-training-cpu"
fi
docker_image_version="latest"
docker_repository="jashwant"

export docker_image_id="${docker_repository}/${docker_image_name}:${docker_image_version}"

if [ "$command" = "build" ] 
then
echo "Building Docker image: ${docker_image_id}"
docker build -t ${docker_image_id} .
docker image prune -f
docker push ${docker_image_id}
elif [ "$command" = "run" ] && [ "$device" = "CPU" ]
then
echo "Running Docker container: ${docker_image_id}"
docker run -it --rm     --name mnist-training     --volume /mnt/data/mnist:/mnt/data/mnist $docker_image_id
elif [ "$command" = "run" ] && [ "$device" = "GPU" ]
then
echo "Running Docker container: ${docker_image_id}"
nvidia-docker run -it --rm     --name mnist-training     --volume /mnt/data/mnist:/mnt/data/mnist $docker_image_id
fi

