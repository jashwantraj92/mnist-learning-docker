python prepare/download-mnist-data.py
